/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 196864
#define R_NICK "Spring Dance"
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "3"
#define R_MINOR  "1.0"
#define R_STATUS ""
#define R_YEAR   "2014"
#define R_MONTH  "04"
#define R_DAY    "10"
#define R_SVN_REVISION 65387
#define R_FILEVERSION    3,10,65387,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
