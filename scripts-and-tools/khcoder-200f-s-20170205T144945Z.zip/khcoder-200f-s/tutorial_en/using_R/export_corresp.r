# Export X-Y coordinates of correspondence analysis plot.

savefile <- NULL
require(tcltk)
savefile <- tclvalue(
    tkgetSaveFile(
        filetypes = "{{CSV Files} {.csv}}",
        defaultextension=".csv"
    )
)

out_data <- cbind(c$cscore[,d_x], c$cscore[,d_y], 1 )  # words
if ( exists("biplot") ){                               # variables
    if (biplot){
        out_data <- rbind(
            out_data, 
            cbind(c$rscore[,d_x], c$rscore[,d_y], 2)
        )
    }
}
out_data <- cbind(rownames(out_data), out_data)        # start finishing
colnames(out_data) <- c("label","x","y","type")
if ( exists("b_size") ){                               # for bubble plots
    if ( exists("biplot") ){
        if (biplot){
            v_size <- sqrt(n_total);
            if (std_radius){ # �召�����f�t�H����
                v_size <- v_size / sd(v_size)
                v_size <- v_size - mean(v_size)
                v_size <- v_size * 5 * bubble_var / 100 + 10
                v_size <- neg_to_zero(v_size)
            }
            b_size <- c(b_size, v_size)
        }
    }
    out_data <- cbind(out_data, b_size)
    colnames(out_data) <- c("label","x","y","type","size")
}
if (nchar(savefile)) {                                 # saving
    write.table(
        out_data,
        savefile,
        sep=",",
        quote=F,
        row.names=F
    )
    print( paste("saved: ",savefile) )
}