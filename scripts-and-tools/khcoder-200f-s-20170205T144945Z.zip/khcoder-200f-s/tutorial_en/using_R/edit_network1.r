# Open Tk plot for free-hand editing.

tkid <- tkplot(
	n2,
	vertex.label       =colnames(d)
	                    [ as.numeric( get.vertex.attribute(n2,"name") ) ],
	vertex.color       =ccol,
	vertex.frame.color =com_col_v,
	vertex.size        =v_size,
	vertex.shape       =v_shape,
	edge.color         =edg_col,
	edge.lty           =edg_lty,
	edge.width         =edg_width,
	layout             =lay_f,
	rescale            =F
)
