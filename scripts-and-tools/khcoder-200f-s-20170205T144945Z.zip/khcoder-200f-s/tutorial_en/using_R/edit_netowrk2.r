# Make changes reflected in the normal plot window. 

lay_f <- tkplot.getcoords(tkid)

lay_f <- scale(lay_f,center=T, scale=F)
for (i in 1:2){
	lay_f[,i] <- lay_f[,i] - min(lay_f[,i]);
	lay_f[,i] <- lay_f[,i] / max(lay_f[,i]);
	lay_f[,i] <- ( lay_f[,i] - 0.5 ) * 1.96;
}
lay_f[,2] <- lay_f[,2] * -1

plot.igraph(
	n2,
	vertex.label       =colnames(d)
	                    [ as.numeric( get.vertex.attribute(n2,"name") ) ],
	vertex.label.cex   =f_size,
	vertex.label.color ="black",
	vertex.label.family= "",
	vertex.label.dist  =vertex_label_dist,
	vertex.color       =ccol,
	vertex.frame.color =com_col_v,
	vertex.size        =v_size,
	vertex.shape       =v_shape,
	edge.color         =edg_col,
	edge.lty           =edg_lty,
	edge.width         =edg_width,
	layout             =lay_f,
	rescale            =F
)

